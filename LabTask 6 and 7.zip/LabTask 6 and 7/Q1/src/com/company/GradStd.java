package com.company;

public class GradStd {
    public GradStd(){

    }
    public void ComGrade(){

    }
}
