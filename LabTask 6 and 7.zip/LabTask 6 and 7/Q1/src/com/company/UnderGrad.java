package com.company;

public class UnderGrad extends Student {
    public UnderGrad(String x,int n){
        super(x,n);
    }
}
