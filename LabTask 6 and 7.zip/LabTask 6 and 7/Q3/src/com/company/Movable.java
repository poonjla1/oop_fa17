package com.company;

public interface Movable {
    void moveup();

    void movedown();

    void moveleft();

    void moveright();

}
