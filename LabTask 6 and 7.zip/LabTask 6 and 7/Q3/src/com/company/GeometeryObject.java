package com.company;

public interface GeometeryObject {

        double getPerimeter();
        double getArea();
    }


