package com.company;

public interface Geo {
}
