package com.company;

public class Main {

    public static void main(String[] args) {
        Circle abc=new Circle(12);


        System.out.println("the area of circle is "+abc.getArea());
        System.out.println("the perimeter of circle is "+abc.getPerimeter());


    }
}
